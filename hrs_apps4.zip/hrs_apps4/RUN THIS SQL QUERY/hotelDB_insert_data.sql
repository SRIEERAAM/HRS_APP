INSERT INTO Rooms (RoomID, RoomType, MaxGuests, BedConfig, SquareFootage, Amenities, ViewType, Price, ImagePath)
VALUES
    ('101', 'Single Room', 1, 'Single Bed', 250, 'TV, WiFi, Minibar, Coffee Maker', 'City View'	, 90.00, 'images/img_1.jpg'),
	('102', 'Single Room', 1, 'Single Bed', 250, 'TV, WiFi, Minibar, Coffee Maker', 'City View'	, 90.00, 'images/img_1.jpg'),
    ('103', 'Single Room', 1, 'Single Bed', 250, 'TV, WiFi, Minibar, Coffee Maker', 'City View'	, 90.00, 'images/img_1.jpg'),
	('104', 'Single Room', 1, 'Single Bed', 250, 'TV, WiFi, Minibar, Coffee Maker', 'Ocean View', 90.00, 'images/img_1.jpg'),
    ('105', 'Single Room', 1, 'Single Bed', 250, 'TV, WiFi, Minibar, Coffee Maker', 'Ocean View', 90.00, 'images/img_1.jpg'),
	('106', 'Single Room', 1, 'Single Bed', 250, 'TV, WiFi, Minibar, Coffee Maker', 'Ocean View', 90.00, 'images/img_1.jpg'),

	('201', 'Standard Room', 2, 'Queen Bed', 350, 'TV, WiFi, Minibar, Coffee Maker', 'City View' , 120.00,'images/img_2.jpg'),
	('202', 'Standard Room', 2, 'Queen Bed', 350, 'TV, WiFi, Minibar, Coffee Maker', 'City View' , 120.00,'images/img_2.jpg'),
	('203', 'Standard Room', 2, 'Queen Bed', 350, 'TV, WiFi, Minibar, Coffee Maker', 'City View' , 120.00,'images/img_2.jpg'),
	('204', 'Standard Room', 2, 'Queen Bed', 350, 'TV, WiFi, Minibar, Coffee Maker', 'Ocean View', 120.00,'images/img_2.jpg'),
	('205', 'Standard Room', 2, 'Queen Bed', 350, 'TV, WiFi, Minibar, Coffee Maker', 'Ocean View', 120.00,'images/img_2.jpg'),

	('301', 'Family Room', 6, '1 King Bed and 2 Twin Beds', 600, 'TV, WiFi, Minibar, Sofa Bed, Balcony', 'City View' , 170.00,'images/img_3.jpg'),
    ('302', 'Family Room', 6, '1 King Bed and 2 Twin Beds', 600, 'TV, WiFi, Minibar, Sofa Bed, Balcony', 'Pool View' , 170.00,'images/img_3.jpg'),
    ('303', 'Family Room', 6, '1 King Bed and 2 Twin Beds', 600, 'TV, WiFi, Minibar, Sofa Bed, Balcony', 'Ocean View', 170.00,'images/img_3.jpg'),

	('401', 'Presidential Suite', 3, '1 King Bed, Living Area', 800, 'TV, WiFi, Minibar, Sofa, Jacuzzi, Balcony', 'Ocean View', 500.00,'images/img_4.jpg'),
	('402', 'Presidential Suite', 3, '1 King Bed, Living Area', 800, 'TV, WiFi, Minibar, Sofa, Jacuzzi, Balcony', 'City View' , 500.00,'images/img_4.jpg')
;