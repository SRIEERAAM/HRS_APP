CREATE TABLE Rooms (
    RoomID VARCHAR(10) PRIMARY KEY,
    RoomType VARCHAR(50) NOT NULL,
    MaxGuests INT NOT NULL,
    BedConfig VARCHAR(50) NOT NULL,
    SquareFootage INT NOT NULL,
    Amenities VARCHAR(255),
    ViewType VARCHAR(50),
    Price DECIMAL(10,2) NOT NULL,
	ImagePath VARCHAR(255)
);

CREATE TABLE Guest (
    GuestID INT IDENTITY(1,1) PRIMARY KEY,
    GuestName VARCHAR(255) NOT NULL,
    PhoneNumber VARCHAR(20) NOT NULL,
    Email VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE Payment (
    PaymentID INT IDENTITY(1,1) PRIMARY KEY,
    PaymentRefNo VARCHAR(50) NOT NULL UNIQUE,
    PaymentAmount DECIMAL(10,2) NOT NULL,
    CardNumber VARCHAR(25) NOT NULL,
    ExpirationDate VARCHAR(5) NOT NULL,					 -- Stored as "MM/YY"
    CVVCode VARCHAR(3) NOT NULL,
	PaymentStatus VARCHAR(50) NOT NULL DEFAULT 'Pending'
);

CREATE TABLE Reservation (
    ReservationID INT IDENTITY(1,1) PRIMARY KEY,
    GuestID INT NOT NULL,
    RoomID VARCHAR(10) NOT NULL,
    CheckInDate DATE NOT NULL,
    CheckOutDate DATE NOT NULL,
    Adults INT NOT NULL,
    Children INT NOT NULL,
    Remarks VARCHAR(255),
    RsvStatus VARCHAR(50) NOT NULL DEFAULT 'Pending',
    PaymentID INT,

	FOREIGN KEY (GuestID) REFERENCES Guest(GuestID) ,
	FOREIGN KEY (RoomID) REFERENCES Rooms(RoomID),
	FOREIGN KEY (PaymentID) REFERENCES Payment(PaymentID)
);



