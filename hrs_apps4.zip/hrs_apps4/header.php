 <!DOCTYPE HTML>
 <html>
	<head>
	  <meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">  
	  <title>Lava Hotel</title>
	  
	  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	  <meta name="description" content="" />
	  <meta name="keywords" content="" />
	  <meta name="author" content="" />
	  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=|Roboto+Sans:400,700|Playfair+Display:400,700">

	<!-- Style Sheet -->
	  <link rel="stylesheet" href="css/bootstrap.min.css">
	  <link rel="stylesheet" href="css/animate.css">
	  <link rel="stylesheet" href="css/owl.carousel.min.css">
	  <link rel="stylesheet" href="css/aos.css">
	  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
	  <link rel="stylesheet" href="css/jquery.timepicker.css">
	  <link rel="stylesheet" href="css/fancybox.min.css">
	 
	  <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
	  <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">

	  <link rel="stylesheet" href="css/style.css">
	  	
	</head>	
<!-- end header -->