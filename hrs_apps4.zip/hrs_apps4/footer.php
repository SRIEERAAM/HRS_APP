   <footer class="section footer-section">
      <div class="container">
        <div class="row mb-4">
          <div class="col-md-6 mb-5">
            <ul class="list-unstyled link">
              <li><a href="#">About Us</a></li>
             <li><a href="rooms.php">Rooms & Suites</a></li>
			 <li><a href="reservation.php">Reservation</a></li>
            </ul>
          </div>
          <div class="col-md-6 mb-5 pr-md-5 contact-info">
            <p><span class="d-block"><span class="ion-ios-location h5 mr-3 text-primary"></span>Address:</span> <span> Persiaran Multimedia, <br> 63100 Cyberjaya, Selangor</span></p>
            <p><span class="d-block"><span class="ion-ios-telephone h5 mr-3 text-primary"></span>Phone:</span> <span> (+60) 19 435 3533</span></p>
            <p><span class="d-block"><span class="ion-ios-email h5 mr-3 text-primary"></span>Email:</span> <span> info@lava.com</span></p>
          </div>
        </div>
        <div class="row pt-5">
          <p class="col-md-6 text-left">
            Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved
          </p>
            
         
        </div>
      </div>
    </footer>
		
	<!-- JavaScript -->
	<?php include 'js.php';?> 
	  
  </body>
</html>